alert("Welcome to my HTML CSS and Javascript SBA webpage");

function inputintake(){
    let password = document.getElementById("password").value;
    let email = document.getElementById("email").value;
    let username = document.getElementById("user_name").value;
    let lastname= document.getElementById("last_name").value;
    let firstname =  document.getElementById("first_name").value;
    document.querySelector("h2").innerHTML= "<p>Please check your information</br>" + firstname + lastname</p>";
    if(password != "password") {
        console.log("Invalid Password") 
    }
    document.getElementById("password").value="";
    document.getElementById("email").value="";
    document.getElementById("user_name").value="";
    document.getElementById("last_name").value="";
    document.getElementById("first_name").value="";
   }
  
